from discordsFunctionalities.runBot import run_discord_bot


if __name__ == '__main__':
    run_discord_bot()

